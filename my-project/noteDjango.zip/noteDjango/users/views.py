# from django.views.decorators.csrf import csrf_exempt
# from django.utils.decorators import method_decorator
# from dj_rest_auth.views import LoginView
# from notsDjango.utulities import BaseViewSet,DynamicModelViewSet
# from .serializers import UserSerializer
# from django.contrib.auth import get_user_model
# from rest_framework.response import Response
# User = get_user_model()

# # UserDetailView: get the current user by token

# class UserDetailView(BaseViewSet):
#     serializer_class = UserSerializer

#     def get_queryset(self):
#         # استرجاع المستخدم الحالي فقط
#         return User.objects.filter(id=self.request.user.id).only('id', 'username', 'email', 'is_superuser', 'last_name', 'first_name', 'is_staff', 'is_active')

#     def retrieve(self, request, pk=None):
#         user = request.user  # استرجاع المستخدم الحالي من التوكن
#         serializer = self.serializer_class(user)
#         return Response(serializer.data)
    
# # get all ``User`` objects
# class UserViewSet(DynamicModelViewSet):
#     model = User
#     serializer_class = UserSerializer

#     def get_permissions(self):
#         return super().get_default_permissions()


# accounts/views.py
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import RegisterSerializer, LoginSerializer
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken
from django.utils.timezone import now

def set_cookie(response, token):
    response.set_cookie(
        key='access_token',
        value=token,
        httponly=True,
        secure=True,
        samesite='Lax',
        max_age=3600  # ساعة مثلاً
    )

class RegisterView(APIView):
    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            refresh = RefreshToken.for_user(user)
            response = Response({"msg": "User created"}, status=status.HTTP_201_CREATED)
            set_cookie(response, str(refresh.access_token))
            return response
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class LoginView(APIView):
    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():
            user = authenticate(
                username=serializer.validated_data['username'],
                password=serializer.validated_data['password']
            )
            if user is not None:
                refresh = RefreshToken.for_user(user)
                response = Response({"msg": "Login successful"}, status=status.HTTP_200_OK)
                set_cookie(response, str(refresh.access_token))
                return response
            return Response({"error": "Invalid credentials"}, status=status.HTTP_401_UNAUTHORIZED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class LogoutView(APIView):
    def post(self, request):
        response = Response({"msg": "Logged out"}, status=status.HTTP_200_OK)
        response.delete_cookie('access_token')
        return response
