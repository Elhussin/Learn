from django.urls import path, include
from rest_framework.routers import DefaultRouter
# from .views import CustomerViewSet, InteractionViewSet, ComplaintViewSet

router = DefaultRouter()
# router.register(r'customers', CustomerViewSet)
# router.register(r'interactions', InteractionViewSet)
# router.register(r'complaints', ComplaintViewSet)

urlpatterns = [
    path('api/', include(router.urls)),
]