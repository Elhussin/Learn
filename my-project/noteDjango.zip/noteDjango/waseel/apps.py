from django.apps import AppConfig


class WaseelConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'waseel'
