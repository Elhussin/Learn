
const waseelUsers = [
    { username: "hsm01", label: "JIM", provider: 917, password: "opt666" },
    { username: "huss_nakheel", label: "Nakheel", provider: 100507, password: "Hussam*7287" },
  ];

export { waseelUsers };